package railway.management.system;
import java.sql.*;
import java.awt.*;
import javax.swing.*;
import java.math.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
public class detailsFrame extends javax.swing.JFrame {
    public detailsFrame() {
        initComponents();
        remove(newbpanel);
        remove(deletebpanel);
        remove(previousbpanel);
        remove(infopanel);
    }
    @SuppressWarnings("unchecked")
    int row;
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        sidepanel = new javax.swing.JPanel();
        SP2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        SP1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        SP3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        SP4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        previousbpanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel28 = new javax.swing.JLabel();
        deletebpanel = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        newbpanel = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        infopanel = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();
        trainlabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(0, 23, 1350, 700));
        setMinimumSize(new java.awt.Dimension(1350, 900));
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(null);

        sidepanel.setBackground(new java.awt.Color(0,0,0,150));

        SP2.setOpaque(false);
        SP2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                SP2MousePressed(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SP2MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SP2MouseEntered(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Kokonor", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Previous Bookings");

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/sand-clock-vector-icon-isolated-transparent-background-logo-concept-design-122566555.png"))); // NOI18N

        javax.swing.GroupLayout SP2Layout = new javax.swing.GroupLayout(SP2);
        SP2.setLayout(SP2Layout);
        SP2Layout.setHorizontalGroup(
            SP2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SP2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(39, 39, 39))
        );
        SP2Layout.setVerticalGroup(
            SP2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SP2Layout.createSequentialGroup()
                .addGroup(SP2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SP2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8))
                    .addGroup(SP2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel4)))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/Mylogo.jpg"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel2MousePressed(evt);
            }
        });

        SP1.setOpaque(false);
        SP1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                SP1MousePressed(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SP1MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SP1MouseEntered(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Kokonor", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("New Booking");

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/500_F_223985198_6MRkrjq8ldwltNpyQYbqRUN1u0ndZ5IV.png"))); // NOI18N

        javax.swing.GroupLayout SP1Layout = new javax.swing.GroupLayout(SP1);
        SP1.setLayout(SP1Layout);
        SP1Layout.setHorizontalGroup(
            SP1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SP1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(29, 29, 29)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67))
        );
        SP1Layout.setVerticalGroup(
            SP1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SP1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(SP1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        SP3.setOpaque(false);
        SP3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                SP3MousePressed(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SP3MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SP3MouseEntered(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Kokonor", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Change Password");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/information-icon-on-a-transparent-background-vector-20773566.png"))); // NOI18N

        javax.swing.GroupLayout SP3Layout = new javax.swing.GroupLayout(SP3);
        SP3.setLayout(SP3Layout);
        SP3Layout.setHorizontalGroup(
            SP3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SP3Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addGap(50, 50, 50))
        );
        SP3Layout.setVerticalGroup(
            SP3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SP3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(SP3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel9))
                .addGap(57, 57, 57))
        );

        SP4.setOpaque(false);
        SP4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                SP4MousePressed(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SP4MouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SP4MouseEntered(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Kokonor", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Cancel Booking");

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/delete.png"))); // NOI18N

        javax.swing.GroupLayout SP4Layout = new javax.swing.GroupLayout(SP4);
        SP4.setLayout(SP4Layout);
        SP4Layout.setHorizontalGroup(
            SP4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SP4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(66, 66, 66))
        );
        SP4Layout.setVerticalGroup(
            SP4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SP4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(SP4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout sidepanelLayout = new javax.swing.GroupLayout(sidepanel);
        sidepanel.setLayout(sidepanelLayout);
        sidepanelLayout.setHorizontalGroup(
            sidepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SP1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(SP4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(SP2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(SP3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(sidepanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        sidepanelLayout.setVerticalGroup(
            sidepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sidepanelLayout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(SP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SP4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SP3, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(263, 263, 263))
        );

        getContentPane().add(sidepanel);
        sidepanel.setBounds(0, 0, 310, 937);

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/back-1689836_960_720.png"))); // NOI18N
        jLabel29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel29MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel29);
        jLabel29.setBounds(1240, 20, 50, 60);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/button-stop-red-cross-warning-hd-png-112793.png"))); // NOI18N
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(1300, 30, 40, 40);

        previousbpanel.setBackground(new java.awt.Color(0,0,0,50));
        previousbpanel.setLayout(null);

        jTable2.setBackground(new java.awt.Color(0,0,0,50));
        jTable2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jTable2.setForeground(new java.awt.Color(255, 255, 255));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "PNR", "Passenger", "Train Name", "Seat No.", "Journey Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setRowHeight(40);
        jTable2.setRowSelectionAllowed(false);
        jTable2.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jTable2.setShowGrid(true);
        jTable2.getTableHeader().setReorderingAllowed(false);
        jTable2.setUpdateSelectionOnSort(false);
        jTable2.setVerifyInputWhenFocusTarget(false);
        jScrollPane3.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
            jTable2.getColumnModel().getColumn(0).setPreferredWidth(50);
            jTable2.getColumnModel().getColumn(1).setResizable(false);
            jTable2.getColumnModel().getColumn(1).setPreferredWidth(200);
            jTable2.getColumnModel().getColumn(2).setResizable(false);
            jTable2.getColumnModel().getColumn(2).setPreferredWidth(250);
            jTable2.getColumnModel().getColumn(3).setResizable(false);
            jTable2.getColumnModel().getColumn(3).setPreferredWidth(7);
            jTable2.getColumnModel().getColumn(4).setResizable(false);
            jTable2.getColumnModel().getColumn(4).setPreferredWidth(100);
        }

        previousbpanel.add(jScrollPane3);
        jScrollPane3.setBounds(50, 220, 950, 430);

        jLabel28.setFont(new java.awt.Font("Kokonor", 3, 48)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Bookings History");
        previousbpanel.add(jLabel28);
        jLabel28.setBounds(340, 90, 380, 82);

        getContentPane().add(previousbpanel);
        previousbpanel.setBounds(310, 0, 1040, 960);

        deletebpanel.setBackground(new java.awt.Color(0,0,0,50));
        deletebpanel.setLayout(null);

        jLabel10.setFont(new java.awt.Font("Kokonor", 3, 48)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 51, 0));
        jLabel10.setText("Delete a Booking:");
        deletebpanel.add(jLabel10);
        jLabel10.setBounds(280, 60, 360, 82);

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 0, 0));
        jLabel20.setText("Enter PNR :");
        deletebpanel.add(jLabel20);
        jLabel20.setBounds(240, 210, 210, 61);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        deletebpanel.add(jTextField1);
        jTextField1.setBounds(450, 220, 300, 40);

        jLabel26.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 0, 0));
        jLabel26.setText("Enter Login Password :");
        deletebpanel.add(jLabel26);
        jLabel26.setBounds(80, 290, 370, 61);
        deletebpanel.add(jTextField2);
        jTextField2.setBounds(450, 300, 300, 40);

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Kokonor", 0, 24)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(255, 0, 0));
        jTextArea1.setRows(5);
        jTextArea1.setText("Terms & Conditions:\n1.Cancellation is irreversible. Once cancelled cannot be claimed back.\n2.On rebooking the ticket you will be added to the same queue as others.\n3.No canellation charges.\n4.Passenger details are retained for further interactions.");
        jTextArea1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTextArea1.setOpaque(false);
        jScrollPane2.setViewportView(jTextArea1);

        deletebpanel.add(jScrollPane2);
        jScrollPane2.setBounds(120, 430, 720, 220);

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 0, 0));
        jButton4.setText("Delete");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        deletebpanel.add(jButton4);
        jButton4.setBounds(250, 740, 210, 70);

        jButton5.setFont(new java.awt.Font("Kokonor", 0, 36)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 0, 0));
        jButton5.setText("Cancel");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        deletebpanel.add(jButton5);
        jButton5.setBounds(470, 740, 200, 70);

        getContentPane().add(deletebpanel);
        deletebpanel.setBounds(310, 0, 1040, 910);

        newbpanel.setBackground(new java.awt.Color(0,0,0,50));
        newbpanel.setForeground(new java.awt.Color(255, 0, 0));
        newbpanel.setFont(new java.awt.Font("Kokonor", 1, 18)); // NOI18N
        newbpanel.setLayout(null);

        jLabel11.setFont(new java.awt.Font("Kokonor", 0, 48)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Enter Booking Details");
        newbpanel.add(jLabel11);
        jLabel11.setBounds(250, 30, 453, 82);

        jTable1.setBackground(new java.awt.Color(0,0,0,100));
        jTable1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable1.setFont(new java.awt.Font("Corsiva Hebrew", 1, 14)); // NOI18N
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"", "", "", "", "", null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                " Aadhar", "First Name", "Middle Name", "Last Name", "DOB", "Gender(M/F)", "Quota(G/S/H)", "Meal(0/V/NV)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setAlignmentX(1.0F);
        jTable1.setAlignmentY(1.0F);
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
        jTable1.setColumnSelectionAllowed(true);
        jTable1.setDropMode(javax.swing.DropMode.INSERT);
        jTable1.setEnabled(false);
        jTable1.setFocusTraversalKeysEnabled(false);
        jTable1.setFocusable(false);
        jTable1.setGridColor(new java.awt.Color(0,0,0,150));
        jTable1.setRowHeight(50);
        jTable1.setRowMargin(0);
        jTable1.setSelectionBackground(new java.awt.Color(0,0,0,100));
        jTable1.setSelectionForeground(new java.awt.Color(0,0,0,100));
        jTable1.setSelectionMode(0);
        jTable1.setShowGrid(true);
        jTable1.getTableHeader().setResizingAllowed(false);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jTable1.setUpdateSelectionOnSort(false);
        jTable1.setVerifyInputWhenFocusTarget(false);
        jScrollPane1.setViewportView(jTable1);
        jTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
        }

        newbpanel.add(jScrollPane1);
        jScrollPane1.setBounds(80, 140, 880, 270);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mumbai-Delhi Express", "Delhi-Mumbai Express", "Mumbai-Manglore Express", "Manglore-Mumbai Express", "Delhi-Jammu Super FastExpress", "Jammu-Delhi SuperFast Express", "Mumbai-Chennai Express", "Chennai-Mumbai Express", " " }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        newbpanel.add(jComboBox1);
        jComboBox1.setBounds(220, 460, 200, 30);

        jLabel14.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Select Train:");
        newbpanel.add(jLabel14);
        jLabel14.setBounds(20, 450, 200, 61);

        jLabel15.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("From:");
        newbpanel.add(jLabel15);
        jLabel15.setBounds(110, 540, 130, 40);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        newbpanel.add(jComboBox2);
        jComboBox2.setBounds(220, 540, 200, 30);

        jLabel16.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("TO:");
        newbpanel.add(jLabel16);
        jLabel16.setBounds(140, 600, 70, 60);

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        newbpanel.add(jComboBox3);
        jComboBox3.setBounds(220, 610, 200, 30);

        jLabel17.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Coach type:");
        newbpanel.add(jLabel17);
        jLabel17.setBounds(510, 580, 220, 61);

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sleeper", "Air Conditioned", "Chair Car", "Others" }));
        newbpanel.add(jComboBox4);
        jComboBox4.setBounds(690, 600, 200, 27);

        jLabel18.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Ticket type:");
        newbpanel.add(jLabel18);
        jLabel18.setBounds(510, 450, 190, 61);

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton1.setText("General");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        newbpanel.add(jRadioButton1);
        jRadioButton1.setBounds(710, 450, 180, 60);

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton2.setText("Tatkal");
        newbpanel.add(jRadioButton2);
        jRadioButton2.setBounds(710, 520, 190, 50);

        jDateChooser1.setDateFormatString("yyyy-MM-d");
        newbpanel.add(jDateChooser1);
        jDateChooser1.setBounds(510, 710, 220, 40);

        jLabel19.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Date of journey:");
        newbpanel.add(jLabel19);
        jLabel19.setBounds(260, 700, 260, 50);

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/kisspng-computer-icons-editing-pencil-icon-5ae26c015e2166.6839283515247882253856.png"))); // NOI18N
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });
        newbpanel.add(jLabel21);
        jLabel21.setBounds(10, 150, 60, 60);

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/kisspng-computer-icons-editing-pencil-icon-5ae26c015e2166.6839283515247882253856.png"))); // NOI18N
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });
        newbpanel.add(jLabel22);
        jLabel22.setBounds(10, 200, 60, 60);

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/kisspng-computer-icons-editing-pencil-icon-5ae26c015e2166.6839283515247882253856.png"))); // NOI18N
        jLabel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel23MouseClicked(evt);
            }
        });
        newbpanel.add(jLabel23);
        jLabel23.setBounds(10, 240, 60, 70);

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/kisspng-computer-icons-editing-pencil-icon-5ae26c015e2166.6839283515247882253856.png"))); // NOI18N
        jLabel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel24MousePressed(evt);
            }
        });
        newbpanel.add(jLabel24);
        jLabel24.setBounds(10, 350, 60, 70);

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/kisspng-computer-icons-editing-pencil-icon-5ae26c015e2166.6839283515247882253856.png"))); // NOI18N
        jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel25MousePressed(evt);
            }
        });
        newbpanel.add(jLabel25);
        jLabel25.setBounds(10, 290, 60, 70);

        jButton2.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jButton2.setText("Book");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        newbpanel.add(jButton2);
        jButton2.setBounds(330, 800, 130, 70);

        jButton3.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jButton3.setText("Clear");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        newbpanel.add(jButton3);
        jButton3.setBounds(480, 800, 130, 70);

        getContentPane().add(newbpanel);
        newbpanel.setBounds(310, 0, 1040, 960);

        infopanel.setBackground(new java.awt.Color(0,0,0,50));
        infopanel.setLayout(null);

        jLabel13.setFont(new java.awt.Font("Kokonor", 3, 48)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText(" Reset Pasword:");
        infopanel.add(jLabel13);
        jLabel13.setBounds(670, 90, 374, 82);

        jLabel12.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("New Password:");
        infopanel.add(jLabel12);
        jLabel12.setBounds(610, 280, 250, 50);

        jLabel27.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Reconfirm Password:");
        infopanel.add(jLabel27);
        jLabel27.setBounds(520, 390, 320, 50);

        jButton6.setText("Confirm");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });
        infopanel.add(jButton6);
        jButton6.setBounds(720, 510, 140, 50);

        jButton7.setText("Cancel");
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton7MousePressed(evt);
            }
        });
        infopanel.add(jButton7);
        jButton7.setBounds(880, 510, 150, 50);
        infopanel.add(jPasswordField1);
        jPasswordField1.setBounds(870, 270, 240, 50);
        infopanel.add(jPasswordField2);
        jPasswordField2.setBounds(870, 390, 240, 50);

        getContentPane().add(infopanel);
        infopanel.setBounds(0, 0, 1340, 910);

        trainlabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/68439413-trains-wallpapers-2.jpg"))); // NOI18N
        getContentPane().add(trainlabel);
        trainlabel.setBounds(-5, 0, 1350, 910);

        setSize(new java.awt.Dimension(1348, 827));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MousePressed
        remove(newbpanel);
        remove(deletebpanel);
        remove(previousbpanel);
        remove(infopanel);
       repaint();
       JOptionPane.showMessageDialog(this,"The Railways: Miniproject By Girish Salunke and Kamakshi Shah.");
    }//GEN-LAST:event_jLabel2MousePressed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
                    System.exit(1);   
    }//GEN-LAST:event_jButton1MouseClicked

    private void SP1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP1MouseEntered
        SP1.setOpaque(true);
        SP1.setBackground(new java.awt.Color(0,0,0,160));
        repaint();
    }//GEN-LAST:event_SP1MouseEntered

    private void SP1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP1MouseExited
        SP1.setOpaque(false);
                repaint();
    }//GEN-LAST:event_SP1MouseExited

    private void SP4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP4MouseEntered
       SP4.setOpaque(true);
        SP4.setBackground(new java.awt.Color(0,0,0,160));
        repaint();
    }//GEN-LAST:event_SP4MouseEntered

    private void SP4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP4MouseExited
       SP4.setOpaque(false);
                repaint();
    }//GEN-LAST:event_SP4MouseExited

    private void SP2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP2MouseEntered
        SP2.setOpaque(true);
        SP2.setBackground(new java.awt.Color(0,0,0,160));
        repaint();
    }//GEN-LAST:event_SP2MouseEntered

    private void SP2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP2MouseExited
        SP2.setOpaque(false);
                repaint();
    }//GEN-LAST:event_SP2MouseExited

    private void SP3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP3MouseEntered
       SP3.setOpaque(true);
        SP3.setBackground(new java.awt.Color(0,0,0,160));
        repaint();
    }//GEN-LAST:event_SP3MouseEntered

    private void SP3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP3MouseExited
        SP3.setOpaque(false);
                repaint();
    }//GEN-LAST:event_SP3MouseExited

    private void SP1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP1MousePressed
        jLabel1.setForeground(Color.red);
        jLabel3.setForeground(Color.white);
        jLabel4.setForeground(Color.white);
        jLabel5.setForeground(Color.white);
        this.remove(deletebpanel);
        this.remove(trainlabel);
        this.remove(previousbpanel);
        this.remove(infopanel);
        this.add(newbpanel);
        this.add(trainlabel);
        repaint();
    }//GEN-LAST:event_SP1MousePressed

    private void SP4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP4MousePressed
       jLabel3.setForeground(Color.red);
       jLabel1.setForeground(Color.white);
       jLabel4.setForeground(Color.white);
       jLabel5.setForeground(Color.white);
       this.remove(newbpanel); 
       this.remove(trainlabel);
       this.remove(previousbpanel);
       this.remove(infopanel);
        this.add(deletebpanel);
        this.add(trainlabel);
        repaint();
    }//GEN-LAST:event_SP4MousePressed

    private void SP2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP2MousePressed
        jLabel4.setForeground(Color.red);
       jLabel1.setForeground(Color.white);
       jLabel3.setForeground(Color.white);
       jLabel5.setForeground(Color.white);
       this.remove(newbpanel);
       this.remove(deletebpanel);
       this.remove(infopanel);
       this.remove(trainlabel);
        this.add(previousbpanel);
        this.add(trainlabel);
        settable();
        repaint();
    }//GEN-LAST:event_SP2MousePressed

    private void SP3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP3MousePressed
        jLabel5.setForeground(Color.red);
       jLabel1.setForeground(Color.white);
       jLabel3.setForeground(Color.white);
       jLabel4.setForeground(Color.white);
       this.remove(newbpanel);
       this.remove(deletebpanel);
       this.remove(previousbpanel);
       this.remove(trainlabel);
        this.add(infopanel);
        this.add(trainlabel);
        repaint();
    }//GEN-LAST:event_SP3MousePressed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
         managedb mdb=new managedb();
            mdb.connectdb();
     try{
         int index=0 ;String order="asc";
         if(jComboBox1.getSelectedItem().equals("Mumbai-Delhi Express")){index=1; order="asc";}
         else if(jComboBox1.getSelectedItem().equals("Delhi-Mumbai Express")){index=2;order="desc";}
         else if(jComboBox1.getSelectedItem().equals("Mumbai-Manglore Express")){index=3;order="asc";}
         else if(jComboBox1.getSelectedItem().equals("Manglore-Mumbai Express")){index=4;order="desc";}
         if(jComboBox1.getSelectedItem().equals("Delhi-Jammu Super FastExpress")){index=5;order="asc";}
         if(jComboBox1.getSelectedItem().equals("Jammu-Delhi SuperFast Express")){index=6;order="desc";}
         if(jComboBox1.getSelectedItem().equals("Mumbai-Chennai Express")){index=7;order="asc";}
         if(jComboBox1.getSelectedItem().equals("Chennai-Mumbai Express")){index=8;order="desc";}
         System.out.println("select station_name from Stations s inner join Stops_At a on s.station_code=a.station_code where a.train_no="+index+" order by s.station_code "+order+";");
         
     
     mdb.rs=mdb.stmt.executeQuery("select station_name from Stations s inner join Stops_At a on s.station_code=a.station_code where a.train_no="+index+" order by s.station_code "+order+";");
          
         jComboBox2.removeAllItems();
         
         while(mdb.rs.next())
         {
           jComboBox2.addItem((mdb.rs.getString("station_name")));
                   
         }
     }catch(Exception e){
         
     }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
       Submit s=new Submit();
       s.setVisible(true);
       s.row=0;   
    }//GEN-LAST:event_jLabel21MouseClicked

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        Submit s=new Submit();
       s.setVisible(true);
       s.row=1;
    }//GEN-LAST:event_jLabel22MouseClicked

    private void jLabel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel23MouseClicked
         Submit s=new Submit();
       s.setVisible(true);
       s.row=2;
    }//GEN-LAST:event_jLabel23MouseClicked

    private void jLabel25MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MousePressed
         Submit s=new Submit();
       s.setVisible(true);
       s.row=3;
    }//GEN-LAST:event_jLabel25MousePressed

    private void jLabel24MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel24MousePressed
        Submit s=new Submit();
       s.setVisible(true);
       s.row=4;
    }//GEN-LAST:event_jLabel24MousePressed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
       addPassenger(); allotTicket();
        for(int i=0;i<5;i++)
        {
            for(int j=0;j<8;j++)
            {
                jTable1.setValueAt("", i, j);
            }
        }
       
    }//GEN-LAST:event_jButton2MouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
         if(!(jTextField1.getText()).equals("") &&!(jTextField2.getText()).equals(""))  { deleteticket(Long.parseLong(jTextField1.getText()),jTextField2.getText());}
         else{
             JOptionPane.showMessageDialog(this,"Enter all details");
         }
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
        if(!(jPasswordField1.getText().equals("")) &&!(jPasswordField2.getText().equals("")))
        {
            if(String.valueOf(jPasswordField1.getPassword()).equals(String.valueOf(jPasswordField2.getPassword())))
        {
            changePassword(String.valueOf(jPasswordField1.getPassword()));
            JOptionPane.showMessageDialog(this,"Password Changed");
            jPasswordField1.setText("");
             jPasswordField2.setText("");
        }
            
        }
        else{JOptionPane.showMessageDialog(this,"Enter all details.");}
    }//GEN-LAST:event_jButton6MouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        for(int i=0;i<5;i++)
        {
            for(int j=0;j<8;j++)
            {
                jTable1.setValueAt("", i, j);
            }
        }
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton7MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MousePressed
        jPasswordField1.setText("");
        jPasswordField2.setText("");
    }//GEN-LAST:event_jButton7MousePressed

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked

        jTextField1.setText(""); 
        jTextField2.setText("");
        
    }//GEN-LAST:event_jButton5MouseClicked

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
    managedb mdb=new managedb();
            mdb.connectdb();
     try{
         int index=0 ;String order="asc";
         if(jComboBox1.getSelectedItem().equals("Mumbai-Delhi Express")){index=1; order="asc";}
         else if(jComboBox1.getSelectedItem().equals("Delhi-Mumbai Express")){index=2;order="desc";}
         else if(jComboBox1.getSelectedItem().equals("Mumbai-Manglore Express")){index=3;order="asc";}
         else if(jComboBox1.getSelectedItem().equals("Manglore-Mumbai Express")){index=4;order="desc";}
         if(jComboBox1.getSelectedItem().equals("Delhi-Jammu Super FastExpress")){index=5;order="asc";}
         if(jComboBox1.getSelectedItem().equals("Jammu-Delhi SuperFast Express")){index=6;order="desc";}
         if(jComboBox1.getSelectedItem().equals("Mumbai-Chennai Express")){index=7;order="asc";}
         if(jComboBox1.getSelectedItem().equals("Chennai-Mumbai Express")){index=8;order="desc";}
      mdb.rs=mdb.stmt.executeQuery("select station_code from Stations where station_name='"+jComboBox2.getSelectedItem()+"';");
     mdb.rs.next();
       
     String no=mdb.rs.getString("station_code");
         
     mdb.rs=mdb.stmt.executeQuery("select station_name from Stations s inner join Stops_At a on s.station_code=a.station_code where a.train_no="+index+" and s.station_code>"+no+" "+" order by s.station_code "+order+";");
          
         jComboBox3.removeAllItems();
         
         while(mdb.rs.next())
         {
           jComboBox3.addItem((mdb.rs.getString("station_name")));
                   
         }
     }catch(Exception e){
         System.out.println("The point is: "+e);
     }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jLabel29MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel29MouseClicked
       J1 j=new J1();
       j.setVisible(true);
       dispose();
    }//GEN-LAST:event_jLabel29MouseClicked
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(detailsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(detailsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(detailsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(detailsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new detailsFrame().setVisible(true);
            }
        });
        
   
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel SP1;
    private javax.swing.JPanel SP2;
    private javax.swing.JPanel SP3;
    private javax.swing.JPanel SP4;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JPanel deletebpanel;
    private javax.swing.JPanel infopanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    public static javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JPanel newbpanel;
    private javax.swing.JPanel previousbpanel;
    private javax.swing.JPanel sidepanel;
    private javax.swing.JLabel trainlabel;
    // End of variables declaration//GEN-END:variables

public  void addPassenger() {
         managedb mdb=new managedb();
       mdb.connectdb();
       
        try {
mdb.stmt.executeUpdate("INSERT INTO Passengers VALUES('" + jTable1.getValueAt(0,1) + "','" +jTable1.getValueAt(0,2) + "','"+jTable1.getValueAt(0,3)+"','"+jTable1.getValueAt(0,5)+"','"+jTable1.getValueAt(0,4)+"','"+jTable1.getValueAt(0,6)+"',"+jTable1.getValueAt(0,0)+");");
mdb.stmt.executeUpdate("INSERT INTO Passengers VALUES('" + jTable1.getValueAt(1,1) + "','" +jTable1.getValueAt(1,2) + "','"+jTable1.getValueAt(1,3)+"','"+jTable1.getValueAt(1,5)+"','"+jTable1.getValueAt(1,4)+"','"+jTable1.getValueAt(1,6)+"',"+jTable1.getValueAt(1,0)+");");            
mdb.stmt.executeUpdate("INSERT INTO Passengers VALUES('" + jTable1.getValueAt(2,1) + "','" +jTable1.getValueAt(2,2) + "','"+jTable1.getValueAt(2,3)+"','"+jTable1.getValueAt(2,5)+"','"+jTable1.getValueAt(2,4)+"','"+jTable1.getValueAt(2,6)+"',"+jTable1.getValueAt(2,0)+");");           
mdb.stmt.executeUpdate("INSERT INTO Passengers VALUES('" + jTable1.getValueAt(3,1) + "','" +jTable1.getValueAt(3,2) + "','"+jTable1.getValueAt(3,3)+"','"+jTable1.getValueAt(3,5)+"','"+jTable1.getValueAt(3,4)+"','"+jTable1.getValueAt(3,6)+"',"+jTable1.getValueAt(3,0)+");");           
mdb.stmt.executeUpdate("INSERT INTO Passengers VALUES('" + jTable1.getValueAt(4,1) + "','" +jTable1.getValueAt(4,2) + "','"+jTable1.getValueAt(4,3)+"','"+jTable1.getValueAt(4,5)+"','"+jTable1.getValueAt(4,4)+"','"+jTable1.getValueAt(4,6)+"',"+jTable1.getValueAt(4,0)+");");  
    mdb.closedb();
        } catch (Exception e) {
           System.out.println("illegal entries Auto Ignored");
        }
    }

public void allotTicket()
{
    char ttyp;int train;char coach;
    if (jRadioButton1.isSelected()){
        ttyp='G';
    }
    if (jRadioButton2.isSelected()){
        ttyp='T';
    }
    else{
        ttyp='G';
    }
    coach=((String)jComboBox4.getSelectedItem()).charAt(0);
 managedb mdb=new managedb();
 mdb.connectdb();
 try{
 if(jRadioButton1.isSelected() || jRadioButton2.isSelected()) 
 {    int seat=getSeat(getTrain((String)jComboBox1.getSelectedItem()));
 if(seat<=100){
  JOptionPane.showMessageDialog(this,"Head to Previous bookings tab to view bookings status,PNR & Seat NO.");
    mdb.stmt.executeUpdate("INSERT INTO Tickets VALUES("+(int)(Math.random()*1000000000)+",'"+(String)jComboBox2.getSelectedItem()+"','"+(String)jComboBox3.getSelectedItem()+"','"+ttyp+"','"+coach+"',"+jTable1.getValueAt(0,0)+","+getTrain((String)jComboBox1.getSelectedItem())+","+(++seat)+",'"+mdb.getUsername()+"','"+convertDateToString(jDateChooser1.getDate())+"');");
    mdb.stmt=mdb.conn.createStatement();
    mdb.stmt.executeUpdate("INSERT INTO Tickets VALUES("+(int)(Math.random()*1000000000)+",'"+(String)jComboBox2.getSelectedItem()+"','"+(String)jComboBox3.getSelectedItem()+"','"+ttyp+"','"+coach+"',"+jTable1.getValueAt(1,0)+","+getTrain((String)jComboBox1.getSelectedItem())+","+(++seat)+",'"+mdb.getUsername()+"','"+convertDateToString(jDateChooser1.getDate())+"');");
    mdb.stmt=mdb.conn.createStatement();
    mdb.stmt.executeUpdate("INSERT INTO Tickets VALUES("+(int)(Math.random()*1000000000)+",'"+(String)jComboBox2.getSelectedItem()+"','"+(String)jComboBox3.getSelectedItem()+"','"+ttyp+"','"+coach+"',"+jTable1.getValueAt(2,0)+","+getTrain((String)jComboBox1.getSelectedItem())+","+(++seat)+",'"+mdb.getUsername()+"','"+convertDateToString(jDateChooser1.getDate())+"');");
    mdb.stmt=mdb.conn.createStatement();
    mdb.stmt.executeUpdate("INSERT INTO Tickets VALUES("+(int)(Math.random()*1000000000)+",'"+(String)jComboBox2.getSelectedItem()+"','"+(String)jComboBox3.getSelectedItem()+"','"+ttyp+"','"+coach+"',"+jTable1.getValueAt(3,0)+","+getTrain((String)jComboBox1.getSelectedItem())+","+(++seat)+",'"+mdb.getUsername()+"','"+convertDateToString(jDateChooser1.getDate())+"');");
    mdb.stmt=mdb.conn.createStatement();
    mdb.stmt.executeUpdate("INSERT INTO Tickets VALUES("+(int)(Math.random()*1000000000)+",'"+(String)jComboBox2.getSelectedItem()+"','"+(String)jComboBox3.getSelectedItem()+"','"+ttyp+"','"+coach+"',"+jTable1.getValueAt(4,0)+","+getTrain((String)jComboBox1.getSelectedItem())+","+(++seat)+",'"+mdb.getUsername()+"','"+convertDateToString(jDateChooser1.getDate())+"');");
 }
 
 else{JOptionPane.showMessageDialog(this,"Sorry,One or more tickets could not be booked because the Train is full.");}
 }
 else{
     JOptionPane.showMessageDialog(this,"Enter all details");
 }
 mdb.closedb();
 }
 catch(Exception e)
 {
     System.out.println("Data field is blank");
 }
}
public int getTrain(String tname)
{
    managedb mdb=new managedb();
    mdb.connectdb();
    int tno=0;
    try{
        mdb.rs=mdb.stmt.executeQuery("select train_no from Trains where tname='"+tname+"';");
        mdb.rs.next();
            tno=mdb.rs.getInt("train_no");
           mdb.closedb(); 
    }
    catch(Exception e){System.out.println("Error at stage one: "+e);}
    return tno;
}
public int getSeat(int tno)
{
    managedb mdb=new managedb();
    mdb.connectdb();
    int seat=0;
    try{
        mdb.rs=mdb.stmt.executeQuery("select COUNT(PNR) from Tickets where train_no="+String.valueOf(tno)+" and jdate ='"+convertDateToString(jDateChooser1.getDate())+"';");
        mdb.rs.next();
        seat=mdb.rs.getInt("COUNT(PNR)");
         mdb.closedb(); 
    }
    catch(SQLException e){System.out.println("Error at stage two: "+e);}
    return seat;
}
public void deleteticket(long PNR,String Password)
{
    managedb mdb=new managedb();
    try
    {
        mdb.connectdb();
        if(Password.equals(managedb.getPassword()))
        {
    mdb.stmt.executeUpdate("delete from Tickets where PNR="+PNR);
        JOptionPane.showMessageDialog(this,"Ticket Cancelled");
        jTextField1.setText("");
        jTextField2.setText("");
        }
        else{
            JOptionPane.showMessageDialog(this,"Invalid Password.");
        }
        mdb.closedb();
}catch(Exception e)
{
    JOptionPane.showMessageDialog(this,"Error encountered");
}
}
public void settable()
{  int row=0;
    managedb mdb=new managedb();
    try{
        mdb.connectdb();
        mdb.rs=mdb.stmt.executeQuery("select PNR,f_name,m_name,l_name,train_no,seat_no,jdate from Tickets  inner join Passengers on Passengers.aadhar=Tickets.passenger_id where Tickets.booking_id='"+mdb.getUsername()+"';");
        for(int i=0;i<5;i++)
        {
            for(int j=0;j<20;j++)
            {
                jTable2.setValueAt("", j, i);
            }
        }
        while(mdb.rs.next())
        {//pnr,passenger,train,seatno.,jdate.
            jTable2.setValueAt(mdb.rs.getString("PNR"), row, 0);//clickclock
            String name=mdb.rs.getString("f_name")+" "+mdb.rs.getString("m_name")+" "+mdb.rs.getString("l_name");
            jTable2.setValueAt(name, row, 1);
            String tno=mdb.rs.getString("train_no");
            String str="";
             
              if(tno.equals("1")){str="Mumbai-Delhi Express";}
             else if(tno.equals("2")){str="Delhi-Mumbai Express";}
             else if(tno.equals("3")){str="Mumbai-Manglore Express";}
             else if(tno.equals("4")){str="Manglore-Mumbai Express";}
             else if(tno.equals("5")){str="Delhi-Jammu Super FastExpress";}
             else if(tno.equals("6")){str="Jammu-Delhi SuperFast Express";}
             else if(tno.equals("7")){str="Mumbai-Chennai Express";}
              else if(tno.equals("8")){str="Chennai-Mumbai Express";}
            jTable2.setValueAt(str, row, 2);
            jTable2.setValueAt(mdb.rs.getString("seat_no"), row, 3);
            jTable2.setValueAt(mdb.rs.getString("jdate"), row, 4);
            row++;
        }
        mdb.closedb();
    }catch(Exception e)
    {
       System.out.println("Could not set table because: "+e);
    }
}
public void changePassword(String newpassword)
{
    managedb mdb=new managedb();
    try{
    mdb.connectdb();
    System.out.println("update Accounts set password='"+newpassword+"' where username='"+mdb.getUsername()+"';");
    mdb.stmt.executeUpdate("update Accounts set password='"+newpassword+"' where username='"+mdb.getUsername()+"';");
    }catch(Exception e){
        
    }
}
public String convertDateToString(Date indate)
{
   String dateString = null;
   DateFormat sdfr = new SimpleDateFormat("yyyy-MM-dd");
   try{
	dateString = sdfr.format( indate );
   }catch (Exception ex ){
	System.out.println(ex);
   }
   return dateString;
}

}

