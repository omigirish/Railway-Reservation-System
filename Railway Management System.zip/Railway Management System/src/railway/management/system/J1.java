
package railway.management.system;

import java.sql.*;
import javax.swing.*;
public class J1 extends javax.swing.JFrame {
    
    public J1() {
        initComponents();
      remove(jPanel1);
      remove(CentralPanel);
        }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        Sname = new javax.swing.JTextField();
        Sphone = new javax.swing.JTextField();
        Ssurname = new javax.swing.JTextField();
        Semail = new javax.swing.JTextField();
        Susername = new javax.swing.JTextField();
        Spassword = new javax.swing.JPasswordField();
        signup = new javax.swing.JButton();
        Sclear = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        CentralPanel = new javax.swing.JPanel();
        LoginL = new javax.swing.JLabel();
        usernameL = new javax.swing.JLabel();
        PasswordL = new javax.swing.JLabel();
        Lusername = new javax.swing.JTextField();
        Lpassword = new javax.swing.JPasswordField();
        ConfirmL = new javax.swing.JButton();
        ClearL = new javax.swing.JButton();
        Sidepanel = new javax.swing.JPanel();
        loginpanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        signuppanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ProjectBY: Girish & Kamakshi");
        setAlwaysOnTop(true);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(null);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/button-stop-red-cross-warning-hd-png-112793.png"))); // NOI18N
        jButton1.setBorderPainted(false);
        jButton1.setMaximumSize(new java.awt.Dimension(40, 40));
        jButton1.setMinimumSize(new java.awt.Dimension(40, 40));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton1MousePressed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(1030, 10, 40, 40);

        jLabel1.setFont(new java.awt.Font("Kokonor", 3, 50)); // NOI18N
        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Welcome To The Railways");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(420, 30, 570, 90);

        jPanel1.setBackground(new java.awt.Color(0,0,0,0));
        jPanel1.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Name:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(30, 140, 110, 40);

        jLabel6.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Surname:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(10, 200, 150, 40);

        jLabel7.setFont(new java.awt.Font("Kokonor", 3, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Phone:");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(370, 140, 110, 40);

        jLabel8.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("E-mail:");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(360, 190, 120, 50);

        jLabel9.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Username: ");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(160, 260, 180, 50);

        jLabel10.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Password:");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(170, 310, 150, 40);

        Sname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SnameActionPerformed(evt);
            }
        });
        jPanel1.add(Sname);
        Sname.setBounds(160, 140, 180, 40);

        Sphone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SphoneActionPerformed(evt);
            }
        });
        jPanel1.add(Sphone);
        Sphone.setBounds(490, 140, 180, 40);

        Ssurname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SsurnameActionPerformed(evt);
            }
        });
        jPanel1.add(Ssurname);
        Ssurname.setBounds(160, 200, 180, 40);

        Semail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SemailActionPerformed(evt);
            }
        });
        jPanel1.add(Semail);
        Semail.setBounds(490, 190, 180, 40);

        Susername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SusernameActionPerformed(evt);
            }
        });
        jPanel1.add(Susername);
        Susername.setBounds(330, 260, 210, 40);

        Spassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SpasswordActionPerformed(evt);
            }
        });
        jPanel1.add(Spassword);
        Spassword.setBounds(330, 310, 210, 40);

        signup.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        signup.setLabel("Signup");
        signup.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                signupMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                signupMouseReleased(evt);
            }
        });
        jPanel1.add(signup);
        signup.setBounds(190, 380, 150, 50);

        Sclear.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        Sclear.setText("Clear");
        Sclear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SclearMouseClicked(evt);
            }
        });
        Sclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SclearActionPerformed(evt);
            }
        });
        jPanel1.add(Sclear);
        Sclear.setBounds(360, 380, 150, 50);

        jLabel11.setFont(new java.awt.Font("Kokonor", 2, 48)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Signup");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(270, 20, 150, 70);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(360, 110, 700, 460);

        CentralPanel.setBackground(new java.awt.Color(0, 0, 0,0));
        CentralPanel.setOpaque(false);
        CentralPanel.setLayout(null);

        LoginL.setFont(new java.awt.Font("Kokonor", 0, 48)); // NOI18N
        LoginL.setForeground(new java.awt.Color(255, 255, 255));
        LoginL.setText("LOGIN");
        CentralPanel.add(LoginL);
        LoginL.setBounds(260, 30, 170, 60);

        usernameL.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        usernameL.setForeground(new java.awt.Color(255, 255, 255));
        usernameL.setText("Username:");
        CentralPanel.add(usernameL);
        usernameL.setBounds(70, 160, 170, 40);

        PasswordL.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        PasswordL.setForeground(new java.awt.Color(255, 255, 255));
        PasswordL.setText("Password:");
        CentralPanel.add(PasswordL);
        PasswordL.setBounds(70, 250, 160, 40);

        Lusername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LusernameActionPerformed(evt);
            }
        });
        CentralPanel.add(Lusername);
        Lusername.setBounds(260, 160, 260, 40);
        CentralPanel.add(Lpassword);
        Lpassword.setBounds(260, 246, 260, 40);

        ConfirmL.setFont(new java.awt.Font("Kokonor", 1, 18)); // NOI18N
        ConfirmL.setText("Confirm");
        ConfirmL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ConfirmLMousePressed(evt);
            }
        });
        ConfirmL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmLActionPerformed(evt);
            }
        });
        CentralPanel.add(ConfirmL);
        ConfirmL.setBounds(180, 360, 160, 50);

        ClearL.setFont(new java.awt.Font("Kokonor", 1, 18)); // NOI18N
        ClearL.setText("Clear");
        ClearL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ClearLMousePressed(evt);
            }
        });
        ClearL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearLActionPerformed(evt);
            }
        });
        CentralPanel.add(ClearL);
        ClearL.setBounds(370, 360, 160, 50);

        getContentPane().add(CentralPanel);
        CentralPanel.setBounds(360, 110, 700, 460);

        Sidepanel.setBackground(new java.awt.Color(0, 0, 0,150));

        loginpanel.setOpaque(false);
        loginpanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loginpanelMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                loginpanelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                loginpanelMouseEntered(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Login");

        javax.swing.GroupLayout loginpanelLayout = new javax.swing.GroupLayout(loginpanel);
        loginpanel.setLayout(loginpanelLayout);
        loginpanelLayout.setHorizontalGroup(
            loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, loginpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120))
        );
        loginpanelLayout.setVerticalGroup(
            loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginpanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        signuppanel.setOpaque(false);
        signuppanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signuppanelMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                signuppanelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                signuppanelMouseEntered(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Kokonor", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Sign Up");

        javax.swing.GroupLayout signuppanelLayout = new javax.swing.GroupLayout(signuppanel);
        signuppanel.setLayout(signuppanelLayout);
        signuppanelLayout.setHorizontalGroup(
            signuppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signuppanelLayout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addComponent(jLabel3)
                .addContainerGap(104, Short.MAX_VALUE))
        );
        signuppanelLayout.setVerticalGroup(
            signuppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, signuppanelLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/Mylogo.jpg"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel4MousePressed(evt);
            }
        });

        javax.swing.GroupLayout SidepanelLayout = new javax.swing.GroupLayout(Sidepanel);
        Sidepanel.setLayout(SidepanelLayout);
        SidepanelLayout.setHorizontalGroup(
            SidepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(signuppanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(loginpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(SidepanelLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SidepanelLayout.setVerticalGroup(
            SidepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SidepanelLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(loginpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(signuppanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(73, Short.MAX_VALUE))
        );

        getContentPane().add(Sidepanel);
        Sidepanel.setBounds(0, 0, 340, 590);

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images and docs/Background.jpg"))); // NOI18N
        getContentPane().add(Background);
        Background.setBounds(-5, -14, 1080, 610);

        setSize(new java.awt.Dimension(1075, 584));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MousePressed
        
       System.exit(0);
    }//GEN-LAST:event_jButton1MousePressed

    private void LusernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LusernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LusernameActionPerformed

    private void ClearLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearLActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ClearLActionPerformed

    private void ConfirmLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmLActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ConfirmLActionPerformed

    private void SpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SpasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SpasswordActionPerformed

    private void SusernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SusernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SusernameActionPerformed

    private void SemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SemailActionPerformed

    private void SsurnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SsurnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SsurnameActionPerformed

    private void SphoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SphoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SphoneActionPerformed

    private void SnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SnameActionPerformed

    private void SclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SclearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SclearActionPerformed

    private void signupMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupMousePressed
if(!(Susername.getText()).equals("") &&!(Spassword.getText()).equals("") && !(Sname.getText()).equals("") && !(Ssurname.getText()).equals("") && !(Sphone.getText()).equals("") && !(Semail.getText()).equals(""))
{
      managedb mdb=new managedb();
        mdb.connectdb();
        
      mdb.addAccount(Susername.getText(),String.valueOf(Spassword.getPassword()),Sphone.getText(),Semail.getText(),Sname.getText(),Ssurname.getText());
      mdb.closedb();
       Sname.setText("");
        Sphone.setText("");
        Spassword.setText("");
        Semail.setText("");
        Ssurname.setText("");
        Susername.setText("");
        JOptionPane.showMessageDialog(this,"Sign up successfull,Proceed with login.");
    }//GEN-LAST:event_signupMousePressed
else{JOptionPane.showMessageDialog(this,"Enter all details.");}
    }
    private void ConfirmLMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConfirmLMousePressed
        int stat;
        managedb mdb=new managedb();
        mdb.connectdb();
        stat=mdb.match(Lusername.getText(),String.valueOf(Lpassword.getPassword()));
        mdb.setUsername(Lusername.getText());
        mdb.setPassword(String.valueOf(Lpassword.getPassword()));
        mdb.closedb();
        if(stat==0)
        {
            JOptionPane.showMessageDialog(getContentPane(),"Incorrect username or Password.");
        }
        else
        {
           detailsFrame df=new detailsFrame();
           df.setVisible(true);
           this.setVisible(false);
        }
        
        
    }//GEN-LAST:event_ConfirmLMousePressed

    private void loginpanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginpanelMouseEntered
       loginpanel.setOpaque(true);
        loginpanel.setBackground(new java.awt.Color(0,0,0,155));
        repaint();
    }//GEN-LAST:event_loginpanelMouseEntered

    private void loginpanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginpanelMouseExited
        loginpanel.setOpaque(false);
                repaint();
    }//GEN-LAST:event_loginpanelMouseExited

    private void signuppanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signuppanelMouseEntered
       signuppanel.setOpaque(true);
        signuppanel.setBackground(new java.awt.Color(0,0,0,155));
        repaint();
    }//GEN-LAST:event_signuppanelMouseEntered

    private void signuppanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signuppanelMouseExited
       signuppanel.setOpaque(false);
                repaint();
    }//GEN-LAST:event_signuppanelMouseExited

    private void loginpanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginpanelMouseClicked
        remove(jPanel1);
        remove(Background);
        jLabel2.setForeground(java.awt.Color.red);
        jLabel3.setForeground(java.awt.Color.white);
        add(CentralPanel);
        add(Background);
       repaint();
    }//GEN-LAST:event_loginpanelMouseClicked

    private void signuppanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signuppanelMouseClicked
         remove(CentralPanel);
        jLabel3.setForeground(java.awt.Color.red);
        jLabel2.setForeground(java.awt.Color.white);
        remove(Background);
        add(jPanel1);
        add(Background);
        
         repaint();
         
    }//GEN-LAST:event_signuppanelMouseClicked

    private void SclearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SclearMouseClicked
        Sname.setText("");
        Sphone.setText("");
        Spassword.setText("");
        Semail.setText("");
        Ssurname.setText("");
        Susername.setText("");
    }//GEN-LAST:event_SclearMouseClicked

    private void ClearLMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ClearLMousePressed
        Lusername.setText("");
        Lpassword.setText("");
    }//GEN-LAST:event_ClearLMousePressed

    private void jLabel4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MousePressed
        JOptionPane.showMessageDialog(this,"Mini-Project by Girish Salunke(S2-2,Roll No.91) & Kamakshi Shah(S2-2,Roll N0:99)");
    }//GEN-LAST:event_jLabel4MousePressed

    private void signupMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_signupMouseReleased

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(J1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(J1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(J1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(J1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new RunnableImpl());
        
      
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JPanel CentralPanel;
    private javax.swing.JButton ClearL;
    private javax.swing.JButton ConfirmL;
    private javax.swing.JLabel LoginL;
    private javax.swing.JPasswordField Lpassword;
    private javax.swing.JTextField Lusername;
    private javax.swing.JLabel PasswordL;
    private javax.swing.JButton Sclear;
    private javax.swing.JTextField Semail;
    private javax.swing.JPanel Sidepanel;
    private javax.swing.JTextField Sname;
    private javax.swing.JPasswordField Spassword;
    private javax.swing.JTextField Sphone;
    private javax.swing.JTextField Ssurname;
    private javax.swing.JTextField Susername;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel loginpanel;
    private javax.swing.JButton signup;
    private javax.swing.JPanel signuppanel;
    private javax.swing.JLabel usernameL;
    // End of variables declaration//GEN-END:variables
    
    

    

    

    private static class RunnableImpl implements Runnable {

        public RunnableImpl() {
        }

        @Override
        public void run() {
            new J1().setVisible(true);
            
        }
    }

  }
class managedb
{   static String usname,password; 
    Connection conn=null;
       Statement stmt=null;
       ResultSet rs=null; 
       
    public void connectdb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/Railways?autoReconnect=true&useSSL=false", "root", "Girish1234");
            stmt = conn.createStatement();

        } catch(Exception e) {
            System.out.println(e);
        }
    }
    public void setUsername(String username)
    {
        usname=username;
        
    }
    public void setPassword(String password)
    {
        this.password=password;
        
    }
    public static String  getUsername()
    {
        return usname;
    }
    public static String  getPassword()
    {
        return password;
    }
    public int match(String username,String password)
    {
        int ret=0;
        try{
              rs=stmt.executeQuery("SELECT password FROM Accounts WHERE username='"+username+"';");
              
            rs.next();
            String pass=rs.getString("password");
            System.out.println(pass);
            if(pass.equals(password))
            {
            ret=1;
            }
            else
            { ret=0;
            }
        }
        catch (Exception e) {
             System.out.println("SELECT password FROM Accounts WHERE username='"+username+"';");
             System.out.println(e);
        
    }
        return ret;
    }
    public  void addAccount(String username,String password,String phone,String email,String name,String surname) {
         
        try {
            stmt.executeUpdate("INSERT INTO accounts VALUES('" + username + "','" + password + "','"+name+"','"+surname+"','"+email+"',"+phone+");");
            
            
            
        } catch (Exception e) {
             System.out.println("INSERT INTO Accounts VALUES('" + username + "','" + password + "','"+name+"','"+surname+"','"+email+"',"+phone+");");
             System.out.println(e);
            
        }
    }
    
        public void closedb() {
        try {
            
            conn.close();
        } catch (SQLException e) {
            System.out.println("Close issue");
        }
    }
}

